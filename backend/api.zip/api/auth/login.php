<?php
require_once __DIR__ . '/../config/auth_helper.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Method not allowed', 450);
}

autoSeedAdminIfEmpty($pdo);

$input = getInputData();
$email = trim($input['email'] ?? '');
$password = trim($input['password'] ?? '');

if (empty($email) || empty($password)) {
    sendError('Please provide both email and password.');
}

$stmt = $pdo->prepare("SELECT id, name, email, password_hash, role, status FROM users WHERE email = :email");
$stmt->execute([':email' => $email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    sendError('Invalid email or password.', 401);
}

if ((int)$user['status'] !== 1) {
    sendError('Your account has been deactivated.', 403);
}

$_SESSION['user_id'] = $user['id'];
$_SESSION['user_email'] = $user['email'];

$token = 'user_' . $user['id'];

sendJson([
    'success' => true,
    'message' => 'Login successful',
    'data' => [
        'token' => $token,
        'user' => [
            'id' => (int)$user['id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role']
        ]
    ]
]);
